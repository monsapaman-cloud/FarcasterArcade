import { type User, type InsertUser, type UserTokens, type DailyGamePlays } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserTokens(userId: string): Promise<UserTokens | undefined>;
  updateUserTokens(userId: string, tokensToAdd: number): Promise<UserTokens>;
  getDailyGamePlays(userId: string, gameId: number, date: string): Promise<DailyGamePlays | undefined>;
  incrementDailyGamePlay(userId: string, gameId: number, tokensEarned: number): Promise<DailyGamePlays>;
  getUserDailyPlayCounts(userId: string, date: string): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private userTokens: Map<string, UserTokens>;
  private dailyPlays: Map<string, DailyGamePlays>;

  constructor() {
    this.users = new Map();
    this.userTokens = new Map();
    this.dailyPlays = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    
    // Initialize user tokens
    const userTokenData: UserTokens = {
      id: randomUUID(),
      userId: id,
      balance: 0,
      totalEarned: 0,
      lastUpdated: new Date()
    };
    this.userTokens.set(id, userTokenData);
    
    return user;
  }

  async getUserTokens(userId: string): Promise<UserTokens | undefined> {
    return this.userTokens.get(userId);
  }

  async updateUserTokens(userId: string, tokensToAdd: number): Promise<UserTokens> {
    let tokens = this.userTokens.get(userId);
    if (!tokens) {
      tokens = {
        id: randomUUID(),
        userId,
        balance: 0,
        totalEarned: 0,
        lastUpdated: new Date()
      };
    }
    
    tokens.balance += tokensToAdd;
    tokens.totalEarned += tokensToAdd;
    tokens.lastUpdated = new Date();
    this.userTokens.set(userId, tokens);
    return tokens;
  }

  async getDailyGamePlays(userId: string, gameId: number, date: string): Promise<DailyGamePlays | undefined> {
    const key = `${userId}-${gameId}-${date}`;
    return this.dailyPlays.get(key);
  }

  async incrementDailyGamePlay(userId: string, gameId: number, tokensEarned: number): Promise<DailyGamePlays> {
    const today = new Date().toISOString().split('T')[0];
    const key = `${userId}-${gameId}-${today}`;
    
    let dailyPlay = this.dailyPlays.get(key);
    if (!dailyPlay) {
      dailyPlay = {
        id: randomUUID(),
        userId,
        gameId,
        playDate: today,
        playCount: 0,
        tokensEarned: 0,
        createdAt: new Date()
      };
    }
    
    dailyPlay.playCount += 1;
    dailyPlay.tokensEarned += tokensEarned;
    this.dailyPlays.set(key, dailyPlay);
    return dailyPlay;
  }

  async getUserDailyPlayCounts(userId: string, date: string): Promise<number> {
    let totalPlays = 0;
    for (const [key, play] of this.dailyPlays.entries()) {
      if (key.startsWith(`${userId}-`) && play.playDate === date) {
        totalPlays += play.playCount;
      }
    }
    return totalPlays;
  }
}

export const storage = new MemStorage();
