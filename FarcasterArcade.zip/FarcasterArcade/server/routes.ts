import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Token and game play API endpoints
  app.get("/api/user-tokens/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const tokens = await storage.getUserTokens(userId);
      if (!tokens) {
        return res.json({ balance: 0, totalEarned: 0 });
      }
      res.json(tokens);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/game-complete", async (req, res) => {
    try {
      const { userId, gameId, won, score } = req.body;
      
      if (!userId || !gameId) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const today = new Date().toISOString().split('T')[0];
      const dailyPlayCount = await storage.getUserDailyPlayCounts(userId, today);
      
      if (dailyPlayCount >= 5) {
        return res.json({ 
          success: false, 
          message: "Daily play limit reached (5 games)",
          tokensEarned: 0,
          dailyPlaysRemaining: 0
        });
      }

      const tokensEarned = won ? 100 : 0;
      
      // Update daily play count
      await storage.incrementDailyGamePlay(userId, gameId, tokensEarned);
      
      // Update user tokens if won
      if (tokensEarned > 0) {
        await storage.updateUserTokens(userId, tokensEarned);
      }

      const updatedDailyCount = await storage.getUserDailyPlayCounts(userId, today);
      
      res.json({ 
        success: true,
        tokensEarned,
        dailyPlaysRemaining: Math.max(0, 5 - updatedDailyCount),
        message: won ? `Congratulations! You earned ${tokensEarned} tokens!` : "Try again!"
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/daily-plays/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const today = new Date().toISOString().split('T')[0];
      const dailyPlayCount = await storage.getUserDailyPlayCounts(userId, today);
      
      res.json({ 
        dailyPlays: dailyPlayCount,
        dailyPlaysRemaining: Math.max(0, 5 - dailyPlayCount),
        maxDailyPlays: 5
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Farcaster authentication proxy endpoint
  app.get("/api/farcaster-user", async (req, res) => {
    try {
      const { fid, username } = req.query;
      
      if (!fid && !username) {
        return res.status(400).json({ 
          ok: false, 
          error: "Must provide either fid or username parameter" 
        });
      }

      const NEYNAR_API_KEY = process.env.NEYNAR_API_KEY;
      if (!NEYNAR_API_KEY) {
        return res.status(500).json({ 
          ok: false, 
          error: "Neynar API key not configured" 
        });
      }

      let url: string;
      if (fid) {
        url = `https://api.neynar.com/v2/farcaster/user?fid=${encodeURIComponent(fid as string)}`;
      } else {
        url = `https://api.neynar.com/v2/farcaster/user-by-username?username=${encodeURIComponent(username as string)}`;
      }

      const response = await axios.get(url, {
        headers: { 
          "api_key": NEYNAR_API_KEY,
          "accept": "application/json"
        },
        timeout: 10000, // 10 second timeout
      });

      // Normalize the response structure
      const userData = response.data?.user || response.data;
      if (!userData) {
        return res.status(404).json({ 
          ok: false, 
          error: "User not found" 
        });
      }

      const normalizedUser = {
        fid: userData.fid,
        username: userData.username,
        display_name: userData.display_name || userData.profile?.display_name || "",
        pfp_url: userData.pfp_url || userData.profile?.pfp_url || "",
        bio: userData.bio?.text || userData.profile?.bio?.text || ""
      };

      res.json({ 
        ok: true, 
        user: normalizedUser 
      });

    } catch (error: any) {
      console.error("Farcaster API error:", error.message);
      
      let errorMessage = "Failed to fetch user data";
      let statusCode = 500;

      if (error.response?.status === 404) {
        errorMessage = "User not found";
        statusCode = 404;
      } else if (error.response?.status === 401) {
        errorMessage = "Invalid API key";
        statusCode = 500; // Don't expose auth errors to client
      } else if (error.response?.status === 429) {
        errorMessage = "Too many requests, please try again later";
        statusCode = 429;
      } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
        errorMessage = "Network error, please try again";
      }

      res.status(statusCode).json({ 
        ok: false, 
        error: errorMessage 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
