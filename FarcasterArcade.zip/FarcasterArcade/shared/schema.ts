import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  farcasterFid: text("farcaster_fid"),
  farcasterUsername: text("farcaster_username"),
  displayName: text("display_name"),
  pfpUrl: text("pfp_url"),
  bio: text("bio"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const games = pgTable("games", {
  id: integer("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  imageUrl: text("image_url"),
  gameUrl: text("game_url").notNull(),
  featured: integer("featured").default(0),
  rating: integer("rating").default(0),
  playCount: integer("play_count").default(0),
});

export const gameStats = pgTable("game_stats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  gameId: integer("game_id").references(() => games.id),
  score: integer("score").default(0),
  playTime: integer("play_time").default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userTokens = pgTable("user_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  balance: integer("balance").default(0),
  totalEarned: integer("total_earned").default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const dailyGamePlays = pgTable("daily_game_plays", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  gameId: integer("game_id").references(() => games.id).notNull(),
  playDate: text("play_date").notNull(), // YYYY-MM-DD format
  playCount: integer("play_count").default(1),
  tokensEarned: integer("tokens_earned").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  farcasterFid: true,
  farcasterUsername: true,
  displayName: true,
  pfpUrl: true,
  bio: true,
});

export const insertGameSchema = createInsertSchema(games).pick({
  title: true,
  category: true,
  description: true,
  imageUrl: true,
  gameUrl: true,
  featured: true,
  rating: true,
});

export const insertGameStatsSchema = createInsertSchema(gameStats).pick({
  userId: true,
  gameId: true,
  score: true,
  playTime: true,
});

export const insertUserTokensSchema = createInsertSchema(userTokens).pick({
  userId: true,
  balance: true,
  totalEarned: true,
});

export const insertDailyGamePlaysSchema = createInsertSchema(dailyGamePlays).pick({
  userId: true,
  gameId: true,
  playDate: true,
  playCount: true,
  tokensEarned: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;
export type InsertGameStats = z.infer<typeof insertGameStatsSchema>;
export type GameStats = typeof gameStats.$inferSelect;
export type InsertUserTokens = z.infer<typeof insertUserTokensSchema>;
export type UserTokens = typeof userTokens.$inferSelect;
export type InsertDailyGamePlays = z.infer<typeof insertDailyGamePlaysSchema>;
export type DailyGamePlays = typeof dailyGamePlays.$inferSelect;

// Farcaster API types
export interface FarcasterUser {
  fid: number;
  username: string;
  display_name: string;
  pfp_url: string;
  bio?: {
    text: string;
  };
  profile?: {
    display_name: string;
    pfp_url: string;
    bio?: {
      text: string;
    };
  };
}

export interface FarcasterLoginRequest {
  fid?: string;
  username?: string;
}
