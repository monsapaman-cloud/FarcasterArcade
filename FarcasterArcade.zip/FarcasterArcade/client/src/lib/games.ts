export interface GameData {
  id: number;
  title: string;
  category: string;
  description: string;
  imageUrl: string;
  gameUrl: string;
  featured: boolean;
  rating: number;
}

export const GAME_CATEGORIES = [
  "All",
  "Arcade",
  "Racing",
  "Puzzle",
  "Music",
  "Strategy",
  "Action",
  "Creative"
] as const;

export type GameCategory = typeof GAME_CATEGORIES[number];

// Static game data - in a real app this would come from the database
export const GAMES: GameData[] = [
  {
    id: 1,
    title: "Neon Runner",
    category: "Arcade",
    description: "Fast-paced cyberpunk runner game",
    imageUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
    gameUrl: "/games/game1/index.html",
    featured: false,
    rating: 85
  },
  {
    id: 2,
    title: "Turbo Track",
    category: "Racing",
    description: "High-speed racing on futuristic tracks",
    imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
    gameUrl: "/games/game2/index.html",
    featured: false,
    rating: 92
  },
  {
    id: 3,
    title: "Mind Maze",
    category: "Puzzle",
    description: "Brain-bending puzzle challenges",
    imageUrl: "https://images.unsplash.com/photo-1606092195730-5d7b9af1efc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
    gameUrl: "/games/game3/index.html",
    featured: true,
    rating: 88
  },
  {
    id: 4,
    title: "Beat Master",
    category: "Music",
    description: "Rhythm game with electronic beats",
    imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
    gameUrl: "/games/game4/index.html",
    featured: false,
    rating: 76
  },
  {
    id: 5,
    title: "Cosmic Quest",
    category: "Arcade",
    description: "Space exploration adventure",
    imageUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=240",
    gameUrl: "/games/game5/index.html",
    featured: true,
    rating: 94
  }
];

export function getGameById(id: number): GameData | undefined {
  return GAMES.find(game => game.id === id);
}

export function getGamesByCategory(category: GameCategory): GameData[] {
  if (category === "All") {
    return GAMES;
  }
  return GAMES.filter(game => game.category === category);
}

export function searchGames(query: string, category: GameCategory = "All"): GameData[] {
  const games = getGamesByCategory(category);
  if (!query.trim()) {
    return games;
  }
  
  const searchTerm = query.toLowerCase();
  return games.filter(game => 
    game.title.toLowerCase().includes(searchTerm) ||
    game.description.toLowerCase().includes(searchTerm) ||
    game.category.toLowerCase().includes(searchTerm)
  );
}

export function getFeaturedGames(): GameData[] {
  return GAMES.filter(game => game.featured);
}
