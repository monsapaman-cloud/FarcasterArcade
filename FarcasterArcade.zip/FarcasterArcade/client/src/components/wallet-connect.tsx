import { Button } from "@/components/ui/button";
import { useWallet } from "@/hooks/use-wallet";
import { useEffect } from "react";

export function WalletConnect() {
  const { 
    isConnected, 
    address, 
    balance, 
    isLoading, 
    error, 
    connect, 
    disconnect,
    isBaseNetwork 
  } = useWallet();

  // Load ethers.js from CDN if not available
  useEffect(() => {
    if (typeof window !== 'undefined' && !(window as any).ethers) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/ethers@5.7.2/dist/ethers.min.js';
      script.async = true;
      document.head.appendChild(script);
    }
  }, []);

  if (isConnected && address) {
    return (
      <div className="flex items-center space-x-4">
        <div className="bg-game-card border border-white border-opacity-10 rounded-lg p-3 text-xs" data-testid="wallet-info">
          <div className="space-y-1">
            <div>
              <strong>Address:</strong>{" "}
              <span className="font-mono text-game-muted" data-testid="text-wallet-address">
                {address.slice(0, 6)}...{address.slice(-4)}
              </span>
            </div>
            <div>
              <strong>Balance:</strong>{" "}
              <span className="text-game-accent2" data-testid="text-wallet-balance">
                {balance || "0"} ETH
              </span>
            </div>
            <div className="text-game-muted">
              Network: {isBaseNetwork ? "Base" : "Other"}
              {!isBaseNetwork && (
                <span className="text-yellow-400 ml-2">⚠️ Switch to Base</span>
              )}
            </div>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={disconnect}
          className="text-xs border-game-card hover:bg-game-card text-game-muted hover:text-game-text"
          data-testid="button-disconnect"
        >
          Disconnect
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-end space-y-2">
      <Button
        onClick={connect}
        disabled={isLoading}
        className="px-4 py-2 bg-game-accent2 hover:bg-game-accent2/90 text-white text-sm font-medium"
        data-testid="button-connect-wallet"
      >
        {isLoading ? "Connecting..." : "Connect Wallet (Base)"}
      </Button>
      {error && (
        <div className="text-xs text-red-400 max-w-48 text-right" data-testid="text-wallet-error">
          {error}
        </div>
      )}
    </div>
  );
}
