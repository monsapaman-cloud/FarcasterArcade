import { useState } from "react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { searchGames, getFeaturedGames, type GameData, type GameCategory } from "@/lib/games";

interface GameGridProps {
  selectedCategory: GameCategory;
}

export function GameGrid({ selectedCategory }: GameGridProps) {
  const [searchQuery, setSearchQuery] = useState("");
  
  const filteredGames = searchGames(searchQuery, selectedCategory);
  const featuredGames = getFeaturedGames();

  return (
    <main className="flex-1 p-6" data-testid="game-grid-container">
      {/* Search Bar */}
      <div className="mb-6">
        <div className="max-w-lg">
          <Input
            type="text"
            placeholder="Search games..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border-game-card bg-game-bg text-game-text focus:ring-game-accent focus:border-game-accent"
            data-testid="input-search-games"
          />
        </div>
      </div>

      {/* Game Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6 mb-12" data-testid="games-grid">
        {filteredGames.length === 0 ? (
          <div className="col-span-full text-center py-12 text-game-muted">
            <div className="text-6xl mb-4">🎮</div>
            <div className="text-lg font-medium">No games found</div>
            <div className="text-sm">Try adjusting your search or category filter</div>
          </div>
        ) : (
          filteredGames.map((game) => (
            <GameCard key={game.id} game={game} />
          ))
        )}
      </div>

      {/* Featured Games Section */}
      {featuredGames.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-6 flex items-center text-game-text">
            <span className="w-1 h-8 gradient-accent rounded-full mr-3"></span>
            Featured Games
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6" data-testid="featured-games-grid">
            {featuredGames.map((game) => (
              <FeaturedGameCard key={game.id} game={game} />
            ))}
          </div>
        </div>
      )}
    </main>
  );
}

interface GameCardProps {
  game: GameData;
}

function GameCard({ game }: GameCardProps) {
  return (
    <Link href={`/game?id=${game.id}`}>
      <div 
        className="bg-game-card border border-white border-opacity-6 rounded-2xl p-3 game-card-hover cursor-pointer relative group"
        data-testid={`card-game-${game.id}`}
      >
        <img 
          src={game.imageUrl} 
          alt={game.title}
          className="w-full h-32 object-cover rounded-xl mb-3 bg-black"
          loading="lazy"
        />
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="font-bold text-sm text-game-text" data-testid={`text-game-title-${game.id}`}>
              {game.title}
            </h3>
            <p className="text-xs text-game-muted" data-testid={`text-game-category-${game.id}`}>
              {game.category}
            </p>
          </div>
        </div>
        <div className="absolute bottom-3 right-3 px-3 py-1.5 gradient-accent rounded-full text-xs font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity">
          Play
        </div>
      </div>
    </Link>
  );
}

function FeaturedGameCard({ game }: GameCardProps) {
  return (
    <Link href={`/game?id=${game.id}`}>
      <div 
        className="bg-game-card border border-white border-opacity-6 rounded-2xl p-6 game-card-hover cursor-pointer"
        data-testid={`card-featured-game-${game.id}`}
      >
        <div className="flex items-start space-x-4">
          <img 
            src={game.imageUrl} 
            alt={game.title}
            className="w-24 h-16 object-cover rounded-lg flex-shrink-0"
            loading="lazy"
          />
          <div className="flex-1">
            <h3 className="font-bold text-lg mb-1 text-game-text" data-testid={`text-featured-title-${game.id}`}>
              {game.title}
            </h3>
            <p className="text-sm text-game-muted mb-2" data-testid={`text-featured-description-${game.id}`}>
              {game.description}
            </p>
            <div className="flex items-center space-x-3">
              <span className="text-xs bg-game-accent px-2 py-1 rounded-full text-white">
                {game.category}
              </span>
              <span className="text-xs text-game-accent2" data-testid={`text-featured-rating-${game.id}`}>
                ★★★★★ {(game.rating / 20).toFixed(1)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}
