import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface TokenDisplayProps {
  userId?: string;
}

export function TokenDisplay({ userId }: TokenDisplayProps) {
  const { data: tokens } = useQuery({
    queryKey: [`/api/user-tokens/${userId}`],
    enabled: !!userId,
  });

  const { data: dailyPlays } = useQuery({
    queryKey: [`/api/daily-plays/${userId}`],
    enabled: !!userId,
  });

  if (!userId) return null;

  return (
    <div className="flex items-center space-x-4">
      {/* Token Balance */}
      <div className="bg-game-card border border-white border-opacity-10 rounded-lg px-4 py-2" data-testid="token-balance">
        <div className="flex items-center space-x-2">
          <span className="text-yellow-400 text-lg">🪙</span>
          <div>
            <div className="text-sm font-bold text-game-text" data-testid="text-token-balance">
              {tokens?.balance || 0} Tokens
            </div>
            <div className="text-xs text-game-muted">
              Total: {tokens?.totalEarned || 0}
            </div>
          </div>
        </div>
      </div>

      {/* Daily Plays Remaining */}
      <div className="bg-game-card border border-white border-opacity-10 rounded-lg px-4 py-2" data-testid="daily-plays">
        <div className="flex items-center space-x-2">
          <span className="text-game-accent2 text-lg">🎮</span>
          <div>
            <div className="text-sm font-bold text-game-text" data-testid="text-daily-plays">
              {dailyPlays?.dailyPlaysRemaining || 5}/5 Plays
            </div>
            <div className="text-xs text-game-muted">
              Today
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}