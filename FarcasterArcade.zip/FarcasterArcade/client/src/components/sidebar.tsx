import { Button } from "@/components/ui/button";
import { GAME_CATEGORIES, type GameCategory } from "@/lib/games";

interface SidebarProps {
  selectedCategory: GameCategory;
  onCategoryChange: (category: GameCategory) => void;
}

export function Sidebar({ selectedCategory, onCategoryChange }: SidebarProps) {
  return (
    <aside className="w-56 bg-game-bg bg-opacity-50 border-r border-white border-opacity-8 p-4" data-testid="sidebar">
      <h3 className="text-sm font-medium text-game-muted mb-3 uppercase tracking-wide">
        Categories
      </h3>
      
      <ul className="space-y-2 mb-8">
        {GAME_CATEGORIES.map((category) => (
          <li key={category}>
            <Button
              variant="ghost"
              onClick={() => onCategoryChange(category)}
              className={`w-full text-left px-3 py-2 rounded-lg border text-sm transition-all justify-start ${
                selectedCategory === category
                  ? "border-game-accent gradient-card-hover bg-opacity-80 text-game-text"
                  : "border-game-card bg-transparent text-game-text hover:gradient-card-hover hover:border-game-accent"
              }`}
              data-testid={`button-category-${category.toLowerCase()}`}
            >
              {category} {category === "All" ? "Games" : ""}
            </Button>
          </li>
        ))}
      </ul>

      {/* Stats Section */}
      <div className="space-y-4">
        <div className="bg-game-card border border-white border-opacity-6 rounded-lg p-4">
          <h4 className="text-sm font-semibold mb-2 text-game-text">🏆 Leaderboard</h4>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between" data-testid="leaderboard-entry-1">
              <span className="text-game-text">CryptoGamer</span>
              <span className="text-game-accent2 font-medium">2,340</span>
            </div>
            <div className="flex justify-between" data-testid="leaderboard-entry-2">
              <span className="text-game-text">Web3Master</span>
              <span className="text-game-accent font-medium">1,890</span>
            </div>
            <div className="flex justify-between" data-testid="leaderboard-entry-3">
              <span className="text-game-text">BlockchainPro</span>
              <span className="text-game-muted font-medium">1,650</span>
            </div>
          </div>
        </div>

        <div className="bg-game-card border border-white border-opacity-6 rounded-lg p-4">
          <h4 className="text-sm font-semibold mb-2 text-game-text">📊 Stats</h4>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-game-text">Games Played</span>
              <span className="font-medium text-game-text" data-testid="stat-games-played">127</span>
            </div>
            <div className="flex justify-between">
              <span className="text-game-text">Total Score</span>
              <span className="font-medium text-game-text" data-testid="stat-total-score">15,420</span>
            </div>
            <div className="flex justify-between">
              <span className="text-game-text">Achievements</span>
              <span className="font-medium text-game-text" data-testid="stat-achievements">23</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
