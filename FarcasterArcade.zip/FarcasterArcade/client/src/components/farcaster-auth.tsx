import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface FarcasterUser {
  fid: number;
  username: string;
  display_name: string;
  pfp_url: string;
  bio: string;
}

interface FarcasterAuthProps {
  onLoginSuccess?: (user: FarcasterUser) => void;
}

export function FarcasterAuth({ onLoginSuccess }: FarcasterAuthProps) {
  const [user, setUser] = useState<FarcasterUser | null>(null);
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: async () => {
      // Mock authentication - instant approval
      return new Promise(resolve => {
        setTimeout(() => {
          resolve({
            ok: true,
            user: {
              fid: 12345,
              username: "gamemaster",
              display_name: "Game Master",
              pfp_url: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=64",
              bio: "Gaming enthusiast & Web3 explorer"
            }
          });
        }, 800);
      });
    },
    onSuccess: (data: any) => {
      setUser(data.user);
      onLoginSuccess?.(data.user);
      toast({
        title: "Farcaster Connected!",
        description: `Welcome, @${data.user.username}!`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Connection failed",
        description: "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleLogin = () => {
    loginMutation.mutate();
  };

  const handleLogout = () => {
    setUser(null);
  };

  if (user) {
    return (
      <div className="bg-game-card border border-white border-opacity-10 rounded-lg p-3" data-testid="farcaster-profile">
        <div className="flex items-center space-x-3">
          <img 
            src={user.pfp_url} 
            alt={`${user.username} profile`}
            className="w-9 h-9 rounded-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
          <div className="flex-1 min-w-0">
            <div className="font-bold text-sm text-game-text" data-testid="text-username">
              @{user.username}
            </div>
            {user.display_name && (
              <div className="text-xs text-game-muted truncate" data-testid="text-display-name">
                {user.display_name}
              </div>
            )}
            {user.bio && (
              <div className="text-xs text-game-muted truncate" data-testid="text-bio">
                {user.bio}
              </div>
            )}
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleLogout}
            className="text-xs text-game-muted hover:text-game-text"
            data-testid="button-logout"
          >
            Logout
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-2" data-testid="farcaster-login-form">
      <Button
        onClick={handleLogin}
        disabled={loginMutation.isPending}
        className="px-6 py-2 bg-game-accent hover:bg-game-accent/90 text-white text-sm font-medium"
        data-testid="button-farcaster-login"
      >
        {loginMutation.isPending ? "Connecting..." : "🔗 Connect Farcaster"}
      </Button>
    </div>
  );
}
