import { useState } from "react";
import { FarcasterAuth } from "./farcaster-auth";
import { WalletConnect } from "./wallet-connect";
import { TokenDisplay } from "./token-display";

export function Header() {
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const handleFarcasterLogin = (user: any) => {
    setCurrentUserId(user.fid.toString());
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glassmorphism" data-testid="header">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Brand Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 gradient-accent rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">🎮</span>
          </div>
          <h1 className="text-xl font-extrabold tracking-wide text-game-text" data-testid="text-brand-title">
            My Game Portal
          </h1>
        </div>

        {/* Center - Token Display */}
        <TokenDisplay userId={currentUserId} />

        {/* Authentication Actions */}
        <div className="flex items-center space-x-4">
          <FarcasterAuth onLoginSuccess={handleFarcasterLogin} />
          <WalletConnect />
        </div>
      </div>
    </header>
  );
}
