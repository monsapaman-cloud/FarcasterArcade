import { useState, useCallback, useEffect } from "react";

declare global {
  interface Window {
    ethereum?: any;
  }
}

interface WalletState {
  isConnected: boolean;
  address: string | null;
  balance: string | null;
  chainId: string | null;
  isLoading: boolean;
  error: string | null;
}

const BASE_CHAIN_ID = "0x2105"; // 8453 in hex
const BASE_CHAIN_CONFIG = {
  chainId: BASE_CHAIN_ID,
  chainName: "Base",
  nativeCurrency: {
    name: "ETH",
    symbol: "ETH",
    decimals: 18,
  },
  rpcUrls: ["https://mainnet.base.org"],
  blockExplorerUrls: ["https://basescan.org"],
};

export function useWallet() {
  const [state, setState] = useState<WalletState>({
    isConnected: false,
    address: null,
    balance: null,
    chainId: null,
    isLoading: false,
    error: null,
  });

  const updateError = (error: string | null) => {
    setState(prev => ({ ...prev, error, isLoading: false }));
  };

  const updateState = (updates: Partial<WalletState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const ensureBaseChain = useCallback(async () => {
    const { ethereum } = window;
    if (!ethereum) throw new Error("No wallet found");

    try {
      const currentChainId = await ethereum.request({ method: "eth_chainId" });
      
      if (currentChainId !== BASE_CHAIN_ID) {
        // Try to switch to Base network
        try {
          await ethereum.request({
            method: "wallet_switchEthereumChain",
            params: [{ chainId: BASE_CHAIN_ID }],
          });
        } catch (switchError: any) {
          // If chain doesn't exist, add it
          if (switchError.code === 4902) {
            await ethereum.request({
              method: "wallet_addEthereumChain",
              params: [BASE_CHAIN_CONFIG],
            });
          } else {
            throw switchError;
          }
        }
      }
    } catch (error: any) {
      throw new Error(`Failed to switch to Base network: ${error.message}`);
    }
  }, []);

  const getBalance = useCallback(async (address: string): Promise<string> => {
    const { ethereum } = window;
    if (!ethereum) throw new Error("No wallet found");

    // Use ethers.js if available, otherwise use raw RPC
    if (typeof window !== 'undefined' && (window as any).ethers) {
      const ethers = (window as any).ethers;
      const provider = new ethers.providers.Web3Provider(ethereum);
      const balance = await provider.getBalance(address);
      return ethers.utils.formatEther(balance);
    } else {
      // Fallback to raw RPC call
      const balanceHex = await ethereum.request({
        method: "eth_getBalance",
        params: [address, "latest"],
      });
      const balanceWei = BigInt(balanceHex);
      const balanceEth = Number(balanceWei) / 1e18;
      return balanceEth.toFixed(4);
    }
  }, []);

  const connect = useCallback(async () => {
    const { ethereum } = window;
    if (!ethereum) {
      updateError("Please install MetaMask or Coinbase Wallet");
      return;
    }

    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      // Ensure we're on Base network first
      await ensureBaseChain();

      // Request account access
      const accounts = await ethereum.request({
        method: "eth_requestAccounts",
      });

      if (accounts.length === 0) {
        throw new Error("No accounts found");
      }

      const address = accounts[0];
      const chainId = await ethereum.request({ method: "eth_chainId" });
      const balance = await getBalance(address);

      updateState({
        isConnected: true,
        address,
        balance,
        chainId,
        isLoading: false,
        error: null,
      });
    } catch (error: any) {
      updateError(error.message || "Failed to connect wallet");
    }
  }, [ensureBaseChain, getBalance]);

  const disconnect = useCallback(() => {
    updateState({
      isConnected: false,
      address: null,
      balance: null,
      chainId: null,
      isLoading: false,
      error: null,
    });
  }, []);

  // Listen for account changes
  useEffect(() => {
    const { ethereum } = window;
    if (!ethereum) return;

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        disconnect();
      } else if (accounts[0] !== state.address) {
        // Reconnect with new account
        connect();
      }
    };

    const handleChainChanged = (chainId: string) => {
      updateState({ chainId });
      // Optionally refresh balance when chain changes
      if (state.address) {
        getBalance(state.address).then(balance => {
          updateState({ balance });
        }).catch(() => {
          updateState({ balance: null });
        });
      }
    };

    ethereum.on("accountsChanged", handleAccountsChanged);
    ethereum.on("chainChanged", handleChainChanged);

    return () => {
      ethereum.removeListener("accountsChanged", handleAccountsChanged);
      ethereum.removeListener("chainChanged", handleChainChanged);
    };
  }, [state.address, connect, disconnect, getBalance]);

  return {
    ...state,
    connect,
    disconnect,
    isBaseNetwork: state.chainId === BASE_CHAIN_ID,
  };
}
