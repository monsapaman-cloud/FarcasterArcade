import { useState } from "react";
import { Header } from "@/components/header";
import { Sidebar } from "@/components/sidebar";
import { GameGrid } from "@/components/game-grid";
import { type GameCategory } from "@/lib/games";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<GameCategory>("All");

  return (
    <div className="min-h-screen bg-game-bg">
      <Header />
      
      <div className="pt-16 flex min-h-screen">
        <Sidebar 
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
        />
        <GameGrid selectedCategory={selectedCategory} />
      </div>
    </div>
  );
}
