import { useLocation } from "wouter";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { getGameById } from "@/lib/games";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Game() {
  const [location] = useLocation();
  const params = new URLSearchParams(location.split('?')[1]);
  const gameId = params.get('id');
  const [currentUserId] = useState("12345"); // Mock user ID from Farcaster auth
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const game = gameId ? getGameById(parseInt(gameId, 10)) : null;

  const gameCompleteMutation = useMutation({
    mutationFn: async (gameResult: { userId: string; gameId: number; won: boolean; score: number }) => {
      const response = await apiRequest("POST", "/api/game-complete", gameResult);
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: data.message,
          description: data.tokensEarned > 0 ? `+${data.tokensEarned} tokens earned!` : `${data.dailyPlaysRemaining} plays remaining today`,
        });
        
        // Invalidate token and daily play queries to refresh the UI
        queryClient.invalidateQueries({ queryKey: [`/api/user-tokens/${currentUserId}`] });
        queryClient.invalidateQueries({ queryKey: [`/api/daily-plays/${currentUserId}`] });
      } else {
        toast({
          title: "Daily Limit Reached",
          description: data.message,
          variant: "destructive",
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to save game result",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'gameComplete') {
        const { gameId, won, score } = event.data;
        gameCompleteMutation.mutate({
          userId: currentUserId,
          gameId: parseInt(gameId),
          won,
          score
        });
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [currentUserId, gameCompleteMutation]);

  if (!game) {
    return (
      <div className="min-h-screen bg-game-bg flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="text-6xl mb-4">😞</div>
          <h1 className="text-2xl font-bold text-game-text">Game Not Found</h1>
          <p className="text-game-muted">The game you're looking for doesn't exist.</p>
          <Link href="/">
            <Button className="bg-game-accent hover:bg-game-accent/90 text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Portal
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-game-bg">
      {/* Header */}
      <header className="glassmorphism border-b border-white border-opacity-8" data-testid="game-header">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/">
            <Button variant="ghost" className="text-game-text hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-game-text" data-testid="text-current-game-title">
            {game.title}
          </h1>
          <div className="w-20"></div> {/* Spacer for centering */}
        </div>
      </header>

      {/* Game Content */}
      <main className="flex items-center justify-center p-4 min-h-[calc(100vh-64px)]">
        <div className="w-full max-w-6xl">
          <iframe
            src={game.gameUrl}
            className="w-full h-[600px] border-none rounded-2xl bg-black"
            title={game.title}
            allow="gamepad; fullscreen"
            data-testid="iframe-game-player"
          />
          
          {/* Game Info */}
          <div className="mt-6 bg-game-card border border-white border-opacity-6 rounded-2xl p-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-game-text">{game.title}</h2>
                <p className="text-game-muted">{game.description}</p>
                <div className="flex items-center space-x-4">
                  <span className="text-sm bg-game-accent px-3 py-1 rounded-full text-white">
                    {game.category}
                  </span>
                  <span className="text-sm text-game-accent2" data-testid={`text-game-rating-${game.id}`}>
                    ★★★★★ {(game.rating / 20).toFixed(1)}
                  </span>
                </div>
                
                {/* Win Conditions */}
                <div className="mt-4 p-3 bg-game-accent bg-opacity-20 rounded-lg border border-game-accent border-opacity-30">
                  <h3 className="text-sm font-bold text-game-accent2 mb-1">🏆 Win Condition (100 Tokens):</h3>
                  <p className="text-xs text-game-muted">
                    {game.id === 1 && "Score 500+ points"}
                    {game.id === 2 && "Complete 3 laps"}
                    {game.id === 3 && "Complete 2+ levels"}
                    {game.id === 4 && "Score 5000+ points"}
                    {game.id === 5 && "Survive 3+ waves"}
                  </p>
                  <p className="text-xs text-orange-300 mt-1">Daily limit: 5 games per day</p>
                </div>
              </div>
              <img 
                src={game.imageUrl} 
                alt={game.title}
                className="w-32 h-20 object-cover rounded-lg"
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
