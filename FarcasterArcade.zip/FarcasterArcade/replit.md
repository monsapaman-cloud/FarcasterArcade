# Overview

This is a gaming portal application that combines web3 features with traditional gaming. It's built as a full-stack TypeScript application using React for the frontend and Express.js for the backend, with Drizzle ORM for database management. The application supports Farcaster social authentication and Ethereum wallet connectivity, allowing users to discover, play, and track their gaming activities in a modern web3 environment.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript, using Vite as the build tool
- **Routing**: Wouter for client-side routing (lightweight React Router alternative)
- **State Management**: TanStack Query for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS
- **Styling**: Tailwind CSS with custom gaming theme variables and glassmorphism effects
- **Component Structure**: Modular component architecture with reusable UI components

## Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with proper error handling middleware
- **Development**: Hot reload with Vite in development, esbuild for production bundling
- **Logging**: Custom request/response logging with performance metrics

## Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: Configured for PostgreSQL via Neon Database serverless
- **Schema**: Type-safe schema definitions with Zod validation
- **Migrations**: Drizzle Kit for database schema management
- **Storage Abstraction**: Interface-based storage layer with in-memory implementation for development

## Authentication & Web3 Integration
- **Social Auth**: Farcaster integration via Neynar API for decentralized social login
- **Wallet Connection**: Ethereum wallet integration with Base network support
- **Session Management**: Cookie-based sessions with PostgreSQL session store
- **User Management**: Unified user profiles combining Farcaster and wallet data

## External Dependencies

- **Neynar API**: Farcaster protocol integration for user authentication and social features
- **Neon Database**: Serverless PostgreSQL database hosting
- **Base Network**: Ethereum Layer 2 for wallet connectivity and potential future token operations
- **Ethers.js**: Ethereum wallet interaction and blockchain operations (loaded from CDN)
- **Google Fonts**: Typography (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)
- **Unsplash**: Game preview images and visual assets
- **Replit Platform**: Development environment with cartographer plugin for debugging

The application uses a monorepo structure with shared TypeScript definitions, enabling type safety across the full stack while maintaining clear separation between client and server code.